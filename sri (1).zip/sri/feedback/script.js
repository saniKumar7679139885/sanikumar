// script.js
document.getElementById('feedbackForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Collect form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Normally, you would send this data to a server
    // Here, we simply display a confirmation message

    const responseDiv = document.getElementById('response');
    responseDiv.innerHTML = `<p>Thank you for your feedback, ${name}!</p>`;
    
    // Clear the form
    this.reset();
});
